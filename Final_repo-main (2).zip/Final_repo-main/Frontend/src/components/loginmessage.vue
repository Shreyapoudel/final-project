<template>
  <!-- <b-alert variant="success" show>You will be redirected to the Dashboard Soon !! Please Wait..</b-alert> -->
  <b-alert variant="success" show>Successfully logged in</b-alert>
</template>

<script>
export default {
  props: ["loginErrorMsg"],
};
</script>

